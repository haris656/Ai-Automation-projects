# InstaFetch Pro — Architecture

A self-hosted Instagram reel / post / story viewer and downloader. Built to
demonstrate the core of an IgAnony-style product: **catching the media stream
reliably**, then serving it in multiple formats.

---

## 1. The problem the CEO framed

> "Everything else is simple — the only hard part is catching the stream, and
> keeping it caught, because Instagram changes its streams regularly."

That is exactly right, and this build is organized around it. Two facts drive
the whole design:

1. **Instagram locks media behind a session.** Anonymous requests to its public
   endpoints return `403 / 404 / "empty media response"`. You need a valid
   session cookie (`sessionid`) attached to every request.
2. **Instagram rotates its extraction surface.** The GraphQL `doc_id` used to
   read a post changes every ~2–4 weeks. Any tool hard-wired to one method
   breaks on that schedule. The fix is *redundancy*, not a single clever call.

---

## 2. Stream-catching cascade (the core)

Every fetch runs through three independent engines, in order. The first that
returns a usable video URL wins:

```
shortcode ─► 1. GraphQL  POST /graphql/query  +  X-IG-App-ID  +  doc_id (list)
             │     └─ fails (doc_id rotated / 403) ─┐
             ▼                                       │
          2. ?__a=1   GET /reel/<sc>/?__a=1&__d=dis  │
             │     └─ fails ─────────────────────────┤
             ▼                                        │
          3. yt-dlp  (community extractor, app_id arg, auto-updated)
                                                      │
                          first success ◄─────────────┘
                                  │
                          direct CDN MP4 URL
                                  ▼
                ffmpeg (bundled) → full | audio (mp3) | silent (mp4)
```

**Why this "never breaks":**

| Failure mode | What absorbs it |
|---|---|
| `doc_id` rotated | `DOC_IDS` is a *list*, tried in order; add the new one on top (1-line fix) |
| GraphQL surface changes | `?__a=1` fallback uses a different endpoint shape |
| Both Instagram endpoints change | yt-dlp's Instagram extractor (800+ contributors, patched <24h) |
| yt-dlp goes stale | daily `update_engines.sh` cron keeps it current |

The `doc_id` is the single value most likely to break. Refreshing it:
browser devtools → Network → filter `graphql` → copy the `doc_id` field →
paste at the top of `DOC_IDS` in `backend.py`.

---

## 3. Auth model

Login uses Instagram's **web browser login endpoint**
(`/api/v1/web/accounts/login/ajax/`) — the same request the real site makes
when you type your password. This avoids the mobile-API path that triggers
security checkpoints. The returned `sessionid` is cached to `.web_session.json`
so you log in once; the password is never stored.

A `cookies.txt` import is also supported as an alternative session source
(exported from a logged-in browser), used by both the web requests and yt-dlp.

---

## 4. Inputs supported

| Input | Resolution path |
|---|---|
| Reel / post / TV **link** | parse shortcode → cascade (fastest, most reliable) |
| **@username** | profile HTML scrape → `web_profile_info` → yt-dlp → latest reel → cascade |
| **Story link / username** | session story feed (`feed/user/<id>/story/`) → media |

Username and story lookups hit Instagram's *profile* endpoints, which are
throttled far more aggressively per-account than single-post reads — see §5.

---

## 5. Rate limits — and how IgAnony actually scales

This is the one architectural gap between a single-user local build and a
production service like IgAnony, and it's worth stating precisely:

- **The extraction logic is identical.** IgAnony, AnonyIG, and this tool all
  call the same public Instagram endpoints with the same `X-IG-App-ID` header.
- **The difference is purely infrastructure.** IgAnony runs server-side with a
  **pool of rotating residential proxies + many Instagram tokens**, so traffic
  is spread across hundreds of IPs and no single one hits a `429`. They also
  serve **public profiles only** — same constraint as here.
- A single account on a single IP (this local build) *will* eventually be
  rate-limited on profile/story lookups. Direct reel links are far less
  affected because they're lighter, single-call reads.

**Mitigations already in this build:**

1. **Lookup cache** (`_lookup_cache`, 10-min TTL) — repeating a username search
   doesn't re-hit Instagram, so it stops `429`s from accumulating.
2. **Proxy-rotation layer** (`proxies.txt` + `_next_proxy()`) — drop residential
   proxies in, one per line, and every request cycles through them. This is the
   exact mechanism IgAnony uses, wired in and ready; empty file = direct
   connection. Add an account pool on top and you have IgAnony's model.

So the path from this build to IgAnony's scale is **not a rewrite** — it's
populating `proxies.txt` and rotating a few accounts behind the same cascade.

---

## 6. Request flow (end to end)

```
Browser (frontend.html)
   │  POST /api/info {input}
   ▼
FastAPI (backend.py)
   │  classify input → reel | user | story
   │  resolve() → catch_stream() cascade → metadata + video_url
   ▼
   │  POST /api/download {input, format}        ── queues a job
   │  background: fetch CDN mp4 → ffmpeg (full|audio|silent)
   │  GET /api/status/{id}  ── poll until done
   │  GET /api/download/{id}/file  ── stream file to browser
```

State is in-memory (`jobs`, `_session`, `_lookup_cache`) — fine for a
single-user desktop tool. For multi-user production: move sessions/jobs to
Redis, files to object storage, and add the proxy+account pool from §5.

---

## 7. Tech stack

| Layer | Choice | Why |
|---|---|---|
| API | FastAPI + Uvicorn | async, tiny, fast to stand up |
| Extraction | requests + yt-dlp | direct endpoint control + a maintained fallback |
| Media | ffmpeg via `imageio-ffmpeg` | bundled binary — audio/silent work with no install |
| Frontend | single `frontend.html` | zero build step; vanilla JS, Tabler icons |

---

## 8. Honest limitations

- Public content only (same as every tool in this category, IgAnony included).
- Username/story lookups are rate-limited per account without a proxy pool.
- CDN URLs are time-signed and expire in a few hours, so the app downloads
  immediately rather than storing links.
- Single-process in-memory state; not horizontally scalable as-is (see §6).
