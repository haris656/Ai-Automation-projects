# InstaFetch Pro

A self-hosted Instagram **reel / post / story** viewer and downloader — a working
build of an IgAnony-style product. Catches the media stream reliably and serves
it as full video, audio-only (MP3), or video-without-sound.

> Read **ARCHITECTURE.md** for the full design write-up (stream-catching cascade,
> auth model, rate-limit handling, and how this scales to IgAnony's no-login model).

---

## Features
- **Connect once** with any Instagram account (a throwaway is fine) → session cached.
- Fetch by **reel/post link**, **@username** (latest reel), or **story link**.
- Download **Full** (mp4) · **Audio only** (mp3) · **No audio** (mp4).
- **ffmpeg bundled** via `imageio-ffmpeg` — audio/silent work with no manual install.
- **3-engine stream-catching cascade** (GraphQL → `?__a=1` → yt-dlp) that survives
  Instagram's `doc_id` rotation.
- **Lookup cache** + optional **proxy rotation** (`proxies.txt`) to handle rate limits.

---

## Quick start

```bash
# 1. install dependencies (includes bundled ffmpeg)
pip install -r requirements.txt

# 2. start the backend  (no --reload — it watches the venv otherwise)
uvicorn backend:app

# 3. open the UI
#    double-click frontend.html   (or:  start frontend.html )
```

In the app: **Connect** your Instagram account, then paste a reel link /
@username / story link and pick a format.

---

## Which input to use
| Input | Reliability |
|---|---|
| `instagram.com/reel/XXXX/` | ★★★ most reliable — single lightweight call |
| `@username` | ★★ does an extra profile lookup (Instagram throttles these harder) |
| story link / username | ★★ same profile-endpoint throttling |

If a username returns "rate-limited", wait a few minutes or use a direct reel
link. To remove the limit entirely, add residential proxies to `proxies.txt`
(see ARCHITECTURE.md §5).

---

## Files
```
backend.py         FastAPI server: login + stream-catch cascade + bundled-ffmpeg convert
frontend.html      UI (login → fetch → preview → download), no build step
ARCHITECTURE.md    full design write-up (read this for the assessment)
requirements.txt   Python dependencies
proxies.txt        optional proxy pool (empty by default)
update_engines.sh  daily yt-dlp updater (keeps the fallback engine current)
.gitignore         keeps session/cookies out of version control
```

---

## How "never breaks" works (short version)
Instagram rotates the GraphQL `doc_id` every 2–4 weeks — the only thing that
breaks extraction. `DOC_IDS` in `backend.py` is a list tried in order, with
`?__a=1` and yt-dlp as fallbacks. When all doc_ids expire, paste the current
one (devtools → Network → `graphql/query` → `doc_id`) at the top of the list.
One line. Full detail in ARCHITECTURE.md.

---

*For personal use. Respect creators' copyright and Instagram's Terms of Service.
Public content only — this build does not access private accounts.*
