"""
InstaFetch Pro — Backend (v6, production)

Working approach (validated against instaloader / yt-dlp / web-scraper repos):
  • Auth: log in once with any account → web sessionid cookie (cached to disk).
  • Stream catching cascade (first success wins), all using that session:
        1. GraphQL doc_id   2. ?__a=1   3. yt-dlp
  • Inputs supported:  reel/post/tv URL  ·  @username (latest reel)  ·  story URL
  • Formats:  full (mp4) · audio (mp3) · silent (mp4, no audio)
  • ffmpeg is BUNDLED via imageio-ffmpeg → audio/silent always work, no install.

THE HARD PART = stream catching. Instagram rotates the GraphQL doc_id every
2-4 weeks; that's the only thing that breaks. DOC_IDS is a list tried in order,
with ?__a=1 and yt-dlp as fallbacks → one-line fix when a doc_id expires.
"""

import http.cookiejar
import json
import logging
import re
import shutil
import subprocess
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Literal, Optional

import requests as rq
import yt_dlp
from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("instafetch")

app = FastAPI(title="InstaFetch Pro", version="6.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

BASE_DIR = Path(__file__).parent
DOWNLOAD_DIR = BASE_DIR / "downloads"; DOWNLOAD_DIR.mkdir(exist_ok=True)
SESSION_FILE = BASE_DIR / ".web_session.json"
COOKIES_FILE = BASE_DIR / "cookies.txt"
PROXIES_FILE = BASE_DIR / "proxies.txt"   # optional: one proxy per line

# ── Proxy pool (optional) ─────────────────────────────────────────────────────
# This is the local-scale version of how IgAnony-style services avoid Instagram
# rate limits: spread requests across many IPs. Drop one proxy per line into
# proxies.txt (e.g. http://user:pass@host:port). Empty file = no proxy.
import itertools
_proxy_cycle = None
def _load_proxies():
    global _proxy_cycle
    if PROXIES_FILE.exists():
        proxies = [ln.strip() for ln in PROXIES_FILE.read_text().splitlines()
                   if ln.strip() and not ln.startswith("#")]
        if proxies:
            _proxy_cycle = itertools.cycle(proxies)
            return len(proxies)
    return 0

def _next_proxy() -> Optional[dict]:
    if _proxy_cycle is None:
        return None
    p = next(_proxy_cycle)
    return {"http": p, "https": p}

IG_APP_ID = "936619743392459"
WEB_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")

DOC_IDS = [
    "8845758582119845", "10015901848480474", "24368985919464652",
    "25981206651899035", "9510064595728286",
]

# ── Bundled ffmpeg (no manual install needed) ─────────────────────────────────
def _resolve_ffmpeg() -> Optional[str]:
    try:
        import imageio_ffmpeg
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if p and Path(p).exists():
            return p
    except Exception:
        pass
    return shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")

FFMPEG = _resolve_ffmpeg()
if FFMPEG:
    log.info(f"ffmpeg: {FFMPEG}")
else:
    log.warning("ffmpeg not found — audio/silent will fall back to muxed file")

# ── Session state ─────────────────────────────────────────────────────────────
_session = {"sessionid": None, "csrftoken": None, "ds_user_id": None, "username": None}

def _load_session():
    if SESSION_FILE.exists():
        try:
            d = json.loads(SESSION_FILE.read_text())
            if d.get("sessionid"):
                _session.update(d); log.info(f"Resumed session @{d.get('username')}")
        except Exception:
            pass
_load_session()
_PROXY_COUNT = _load_proxies()
if _PROXY_COUNT:
    log.info(f'proxy pool: {_PROXY_COUNT} proxies loaded')

jobs: dict[str, dict] = {}

# Short-lived cache so repeating the same username/story search doesn't
# re-hit Instagram (which accumulates 429s). This is the local-scale version
# of what IgAnony-style services do with proxy/account pools.
_lookup_cache: dict[str, tuple[float, object]] = {}
_CACHE_TTL = 600  # seconds

def _cache_get(key: str):
    hit = _lookup_cache.get(key)
    if hit and (time.time() - hit[0]) < _CACHE_TTL:
        return hit[1]
    return None

def _cache_put(key: str, value):
    _lookup_cache[key] = (time.time(), value)


# ── Models ────────────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str
    two_factor_code: Optional[str] = None

class InfoRequest(BaseModel):
    input: str

class DownloadRequest(BaseModel):
    input: str
    format: Literal["full", "audio", "silent"] = "full"

class CookiesRequest(BaseModel):
    cookies: str


# ── Input classification ──────────────────────────────────────────────────────
SC_RE = re.compile(r"instagram\.com/(?:[^/?#]+/)?(?:reel|reels|p|tv)/([A-Za-z0-9_-]+)", re.I)
STORY_RE = re.compile(r"instagram\.com/stories/([A-Za-z0-9._]+)/?([0-9]+)?", re.I)

def classify(raw: str) -> tuple[str, str]:
    """Return (kind, value): ('reel', shortcode) | ('user', handle) | ('story', handle)."""
    s = (raw or "").strip().split("?")[0].split("#")[0]
    if not s:
        raise ValueError("Please paste a reel/post link or a username.")
    if not s.startswith("http"):
        # bare shortcode or username
        if re.fullmatch(r"[A-Za-z0-9_-]{6,30}", s) and not s.startswith("@"):
            # ambiguous: treat 11-char as shortcode, else username
            if len(s) in (10, 11) and re.search(r"[-_]", s) is None and any(c.isupper() for c in s):
                return ("reel", s)
        if re.fullmatch(r"@?[A-Za-z0-9._]{1,30}", s):
            return ("user", s.lstrip("@"))
        s = "https://" + s
    sm = STORY_RE.search(s)
    if sm:
        return ("story", sm.group(1))
    m = SC_RE.search(s)
    if m:
        return ("reel", m.group(1))
    # profile URL → username
    pm = re.search(r"instagram\.com/([A-Za-z0-9._]+)/?$", s)
    if pm and pm.group(1) not in ("reel", "reels", "p", "tv", "stories", "explore"):
        return ("user", pm.group(1))
    raise ValueError("Couldn't read that. Use a reel link, a username, or a story link.")


def humanize(err: str) -> str:
    e = (err or "").lower()
    if "429" in e or "rate-limit" in e or "rate limit" in e or "too many" in e or "please wait" in e:
        return ("Instagram rate-limited profile lookups on your account. Wait ~5–10 minutes, "
                "or just paste a direct reel link (instagram.com/reel/…) — those aren't limited the same way.")
    if "not logged in" in e or "login_required" in e or "checkpoint" in e or "challenge" in e:
        return "Session expired or blocked. Reconnect your account (top of the app)."
    if "403" in e or "401" in e or "empty media" in e:
        return "Instagram blocked this request. Reconnect your account, or the post may be private."
    if "404" in e or "not found" in e:
        return "Not found. Check the link/username — the post may be deleted."
    if "could not find a reel" in e:
        return "Couldn't find a reel for that username. Try a direct reel link, or the profile may have no videos."
    if "private" in e:
        return "That account is private — connect an account that follows it."
    if "no posts" in e or "no reels" in e or "no video" in e:
        return "No downloadable video found there."
    if "no stories" in e or "no active" in e:
        return "That user has no active stories right now."
    if "two_factor" in e or "2fa" in e:
        return "Two-factor required — enter your 6-digit code."
    if "bad password" in e or "incorrect" in e or "invalid" in e:
        return "Wrong username or password."
    if "timeout" in e or "connection" in e:
        return "Network error reaching Instagram. Try again."
    return "Couldn't fetch that. Reconnect your account and try a public reel link."


# ── HTTP session ──────────────────────────────────────────────────────────────
def http_session() -> rq.Session:
    s = rq.Session()
    proxy = _next_proxy()
    if proxy:
        s.proxies.update(proxy)
    s.headers.update({
        "User-Agent": WEB_UA, "X-IG-App-ID": IG_APP_ID, "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9", "Accept-Encoding": "gzip, deflate",
        "Referer": "https://www.instagram.com/", "Origin": "https://www.instagram.com",
    })
    if _session["sessionid"]:
        s.cookies.set("sessionid", _session["sessionid"], domain=".instagram.com")
        s.cookies.set("csrftoken", _session["csrftoken"] or "x", domain=".instagram.com")
        if _session.get("ds_user_id"):
            s.cookies.set("ds_user_id", _session["ds_user_id"], domain=".instagram.com")
        s.headers["X-CSRFToken"] = _session["csrftoken"] or "x"
    elif COOKIES_FILE.exists():
        try:
            jar = http.cookiejar.MozillaCookieJar(str(COOKIES_FILE))
            jar.load(ignore_discard=True, ignore_expires=True)
            s.cookies = jar
            csrf = next((c.value for c in jar if c.name == "csrftoken"), None)
            if csrf: s.headers["X-CSRFToken"] = csrf
        except Exception as ex:
            log.warning(f"cookies.txt: {ex}")
    return s

def _cookiefile_for_ytdlp() -> Optional[str]:
    if COOKIES_FILE.exists():
        return str(COOKIES_FILE)
    if _session["sessionid"]:
        tmp = BASE_DIR / ".tmp_cookies.txt"
        lines = ["# Netscape HTTP Cookie File"]
        lines.append(f".instagram.com\tTRUE\t/\tTRUE\t0\tsessionid\t{_session['sessionid']}")
        lines.append(f".instagram.com\tTRUE\t/\tFALSE\t0\tcsrftoken\t{_session['csrftoken'] or 'x'}")
        if _session.get("ds_user_id"):
            lines.append(f".instagram.com\tTRUE\t/\tFALSE\t0\tds_user_id\t{_session['ds_user_id']}")
        tmp.write_text("\n".join(lines) + "\n")
        return str(tmp)
    return None


# ── Web login ─────────────────────────────────────────────────────────────────
def web_login(username: str, password: str, code: str = "") -> dict:
    s = rq.Session()
    proxy = _next_proxy()
    if proxy:
        s.proxies.update(proxy)
    s.headers.update({"User-Agent": WEB_UA, "Accept-Language": "en-US,en;q=0.9"})
    s.get("https://www.instagram.com/accounts/login/", timeout=15)
    csrf = s.cookies.get("csrftoken", "missing")
    enc = f"#PWD_INSTAGRAM_BROWSER:0:{int(time.time())}:{password}"
    r = s.post("https://www.instagram.com/api/v1/web/accounts/login/ajax/",
               data={"username": username.lstrip("@"), "enc_password": enc,
                     "queryParams": "{}", "optIntoOneTap": "false"},
               headers={"X-CSRFToken": csrf, "X-IG-App-ID": IG_APP_ID,
                        "X-Requested-With": "XMLHttpRequest",
                        "Referer": "https://www.instagram.com/accounts/login/"},
               timeout=20)
    try:
        data = r.json()
    except Exception:
        raise RuntimeError(f"login not JSON ({r.status_code})")
    if data.get("two_factor_required"):
        if not code:
            raise RuntimeError("two_factor_required")
        ident = data.get("two_factor_info", {}).get("two_factor_identifier", "")
        r = s.post("https://www.instagram.com/api/v1/web/accounts/login/ajax/two_factor/",
                   data={"username": username.lstrip("@"), "verificationCode": code.strip(),
                         "identifier": ident},
                   headers={"X-CSRFToken": csrf, "X-IG-App-ID": IG_APP_ID,
                            "X-Requested-With": "XMLHttpRequest",
                            "Referer": "https://www.instagram.com/accounts/login/"},
                   timeout=20)
        data = r.json()
    if not data.get("authenticated"):
        raise RuntimeError(data.get("message") or data.get("error_type") or "bad password")
    return {"sessionid": r.cookies.get("sessionid") or s.cookies.get("sessionid"),
            "csrftoken": r.cookies.get("csrftoken") or s.cookies.get("csrftoken") or csrf,
            "ds_user_id": r.cookies.get("ds_user_id") or s.cookies.get("ds_user_id")}


# ── Resolvers (username / story → media) ──────────────────────────────────────
def _profile_info(handle: str) -> dict:
    s = http_session()
    r = s.get(f"https://www.instagram.com/api/v1/users/web_profile_info/?username={handle}",
              headers={"X-IG-App-ID": IG_APP_ID}, timeout=20)
    if r.status_code != 200:
        raise RuntimeError(f"web_profile_info HTTP {r.status_code}")
    return (r.json().get("data") or {}).get("user") or {}

def _profile_html_shortcode(handle: str) -> str:
    """Scrape the profile HTML page for an embedded reel/post shortcode.
    Often less throttled than the web_profile_info JSON API."""
    s = http_session()
    r = s.get(f"https://www.instagram.com/{handle}/", timeout=20,
              headers={"Accept": "text/html,application/xhtml+xml"})
    if r.status_code == 429:
        raise RuntimeError("429 profile html")
    if r.status_code != 200:
        raise RuntimeError(f"profile html HTTP {r.status_code}")
    html = r.text
    codes = re.findall(r'"(?:shortcode|code)":"([A-Za-z0-9_-]{6,30})"', html)
    for c in codes:
        if 6 <= len(c) <= 20:
            return c
    m = re.search(r'/(?:reel|p|tv)/([A-Za-z0-9_-]{6,30})/', html)
    if m:
        return m.group(1)
    raise RuntimeError("no shortcode in profile html")


def username_to_shortcode(handle: str) -> str:
    handle = handle.lstrip("@").strip("/")
    cached = _cache_get("user:" + handle)
    if cached:
        return cached
    sc = _username_to_shortcode_uncached(handle)
    _cache_put("user:" + handle, sc)
    return sc


def _username_to_shortcode_uncached(handle: str) -> str:
    saw_429 = False
    # Method 1: profile HTML scrape (lighter / less throttled)
    try:
        return _profile_html_shortcode(handle)
    except Exception as e:
        if "429" in str(e):
            saw_429 = True
        log.warning(f"[user] html scrape failed: {str(e)[:120]}")
    # Method 2: web_profile_info JSON API
    try:
        user = _profile_info(handle)
        edges = (user.get("edge_owner_to_timeline_media") or {}).get("edges") or []
        for e in edges:
            if e["node"].get("is_video"):
                return e["node"]["shortcode"]
        if edges:
            return edges[0]["node"]["shortcode"]
    except Exception as e:
        if "429" in str(e):
            saw_429 = True
        log.warning(f"[user] web_profile_info failed: {str(e)[:120]}")
    # Method 3: yt-dlp profile listing
    try:
        url = f"https://www.instagram.com/{handle}/"
        opts = {"quiet": True, "no_warnings": True, "socket_timeout": 25,
                "extract_flat": True, "playlistend": 10,
                "extractor_args": {"instagram": {"app_id": [IG_APP_ID]}},
                "http_headers": {"User-Agent": WEB_UA}}
        cf = _cookiefile_for_ytdlp()
        if cf: opts["cookiefile"] = cf
        with yt_dlp.YoutubeDL(opts) as ydl:
            d = ydl.extract_info(url, download=False)
        for e in [x for x in (d.get("entries") or []) if x]:
            sc = e.get("id")
            if isinstance(sc, str) and re.fullmatch(r"[A-Za-z0-9_-]{6,30}", sc):
                return sc
            m = SC_RE.search(e.get("url", "") or e.get("webpage_url", "") or "")
            if m:
                return m.group(1)
    except Exception as e:
        if "429" in str(e):
            saw_429 = True
        log.warning(f"[user] yt-dlp profile failed: {str(e)[:120]}")
    if saw_429:
        raise RuntimeError("rate-limited 429 on profile lookup")
    raise RuntimeError("could not find a reel for that username")

def story_info(handle: str) -> dict:
    user = _profile_info(handle)
    uid = user.get("id")
    if not uid:
        raise RuntimeError("could not resolve user id")
    s = http_session()
    r = s.get(f"https://www.instagram.com/api/v1/feed/user/{uid}/story/",
              headers={"X-IG-App-ID": IG_APP_ID}, timeout=20)
    if r.status_code != 200:
        raise RuntimeError(f"story HTTP {r.status_code}")
    reel = (r.json() or {}).get("reel")
    items = (reel or {}).get("items") or []
    if not items:
        raise RuntimeError("no active stories")
    vids = [it for it in items if it.get("video_versions")]
    item = vids[0] if vids else items[0]
    vv = item.get("video_versions") or []
    img = (((item.get("image_versions2") or {}).get("candidates") or [{}])[0]).get("url")
    return {"video_url": vv[0]["url"] if vv else None, "is_video": bool(vv),
            "uploader": handle, "description": "Story",
            "duration": item.get("video_duration"), "thumbnail": img,
            "view_count": None, "like_count": None, "comment_count": None,
            "image_url": None if vv else img}


# ── Stream-catching cascade (by shortcode) ────────────────────────────────────
def _cap(m):
    try: return m["edge_media_to_caption"]["edges"][0]["node"]["text"]
    except Exception: return ""

def _graphql(shortcode: str) -> dict:
    s = http_session(); last = "no doc_id worked"
    for doc in DOC_IDS:
        try:
            r = s.post("https://www.instagram.com/graphql/query",
                       data={"variables": json.dumps({"shortcode": shortcode}), "doc_id": doc},
                       timeout=20)
            if r.status_code == 403:
                raise RuntimeError("403 not logged in")
            if r.status_code != 200:
                last = f"HTTP {r.status_code}"; continue
            m = ((r.json() or {}).get("data") or {})
            m = m.get("xdt_shortcode_media") or m.get("shortcode_media")
            if not m: last = "no media"; continue
            if not m.get("is_video") and m.get("edge_sidecar_to_children"):
                for e in m["edge_sidecar_to_children"].get("edges", []):
                    if e["node"].get("is_video"):
                        m = {**m, **e["node"]}; break
            if not m.get("video_url"):
                last = "photo post (no video)"; continue
            log.info(f"[graphql] ✓ {doc}")
            return {"video_url": m["video_url"], "is_video": True,
                    "uploader": (m.get("owner") or {}).get("username") or "instagram",
                    "description": _cap(m), "duration": m.get("video_duration"),
                    "view_count": m.get("video_view_count"),
                    "like_count": (m.get("edge_media_preview_like") or {}).get("count"),
                    "comment_count": (m.get("edge_media_to_comment") or {}).get("count"),
                    "thumbnail": m.get("display_url")}
        except RuntimeError:
            raise
        except Exception as e:
            last = str(e)
    raise RuntimeError(f"graphql: {last}")

def _a1(shortcode: str) -> dict:
    s = http_session()
    for ep in (f"https://www.instagram.com/reel/{shortcode}/?__a=1&__d=dis",
               f"https://www.instagram.com/p/{shortcode}/?__a=1&__d=dis"):
        try:
            r = s.get(ep, timeout=20)
            if r.status_code != 200: continue
            items = (r.json() or {}).get("items") or []
            if not items: continue
            it = items[0]
            vv = it.get("video_versions") or []
            if not vv and it.get("carousel_media"):
                for c in it["carousel_media"]:
                    if c.get("video_versions"): vv = c["video_versions"]; break
            if not vv: continue
            cap = (it.get("caption") or {}).get("text", "") if it.get("caption") else ""
            thumb = (((it.get("image_versions2") or {}).get("candidates") or [{}])[0]).get("url")
            log.info("[a1] ✓")
            return {"video_url": vv[0]["url"], "is_video": True,
                    "uploader": (it.get("user") or {}).get("username") or "instagram",
                    "description": cap, "duration": it.get("video_duration"),
                    "view_count": it.get("play_count"), "like_count": it.get("like_count"),
                    "comment_count": it.get("comment_count"), "thumbnail": thumb}
        except Exception:
            continue
    raise RuntimeError("a1: no video")

def _ytdlp(shortcode: str) -> dict:
    url = f"https://www.instagram.com/reel/{shortcode}/"
    opts = {"quiet": True, "no_warnings": True, "socket_timeout": 25,
            "extractor_args": {"instagram": {"app_id": [IG_APP_ID]}},
            "http_headers": {"User-Agent": WEB_UA}}
    cf = _cookiefile_for_ytdlp()
    if cf: opts["cookiefile"] = cf
    with yt_dlp.YoutubeDL(opts) as ydl:
        d = ydl.extract_info(url, download=False)
    if d.get("_type") == "playlist" and d.get("entries"):
        d = next(e for e in d["entries"] if e)
    vurl = d.get("url")
    if not vurl:
        for f in reversed(d.get("formats") or []):
            if f.get("vcodec") not in (None, "none"): vurl = f["url"]; break
    if not vurl:
        raise RuntimeError("yt-dlp no url")
    log.info("[yt-dlp] ✓")
    return {"video_url": vurl, "is_video": True,
            "uploader": d.get("uploader") or "instagram",
            "description": d.get("description") or "", "duration": d.get("duration"),
            "view_count": d.get("view_count"), "like_count": d.get("like_count"),
            "comment_count": d.get("comment_count"), "thumbnail": d.get("thumbnail")}

def catch_stream(shortcode: str) -> tuple[dict, str]:
    errs = []
    for name, fn in (("graphql", _graphql), ("a1", _a1), ("yt-dlp", _ytdlp)):
        try:
            return fn(shortcode), name
        except Exception as e:
            log.warning(f"[{name}] {str(e)[:140]}"); errs.append(f"{name}: {e}")
    raise RuntimeError(" | ".join(errs))


def resolve(kind: str, value: str) -> tuple[dict, str]:
    if kind == "reel":
        return catch_stream(value)
    if kind == "user":
        return catch_stream(username_to_shortcode(value))
    if kind == "story":
        return story_info(value), "story"
    raise RuntimeError("unknown input")


# ── Download + convert (bundled ffmpeg) ───────────────────────────────────────
def fetch_to_file(video_url: str, out: Path) -> Path:
    fn = out / f"ig_{uuid.uuid4().hex[:10]}.mp4"
    s = http_session()
    with s.get(video_url, stream=True, timeout=120) as r:
        r.raise_for_status()
        with open(fn, "wb") as f:
            for chunk in r.iter_content(1 << 15):
                if chunk: f.write(chunk)
    if fn.stat().st_size < 5000:
        fn.unlink(missing_ok=True)
        raise RuntimeError("download too small (stream URL expired) — retry")
    return fn

def to_mp3(src: Path) -> Path:
    if not FFMPEG:
        raise RuntimeError("ffmpeg unavailable")
    dst = src.with_suffix(".mp3")
    p = subprocess.run([FFMPEG, "-i", str(src), "-vn", "-acodec", "libmp3lame",
                        "-q:a", "0", str(dst), "-y"], capture_output=True)
    if p.returncode != 0 or not dst.exists():
        raise RuntimeError("audio conversion failed: " + p.stderr.decode(errors="ignore")[-200:])
    src.unlink(missing_ok=True); return dst

def to_silent(src: Path) -> Path:
    if not FFMPEG:
        raise RuntimeError("ffmpeg unavailable")
    dst = src.with_name(src.stem + "_silent.mp4")
    p = subprocess.run([FFMPEG, "-i", str(src), "-an", "-c:v", "copy", str(dst), "-y"],
                       capture_output=True)
    if p.returncode != 0 or not dst.exists():
        raise RuntimeError("silent conversion failed: " + p.stderr.decode(errors="ignore")[-200:])
    src.unlink(missing_ok=True); return dst

def run_job(job_id: str, kind: str, value: str, fmt: str):
    jobs[job_id]["status"] = "processing"
    try:
        info, engine = resolve(kind, value)
        if not info.get("video_url"):
            raise RuntimeError("no video (photo-only post/story)")
        src = fetch_to_file(info["video_url"], DOWNLOAD_DIR)
        out = to_mp3(src) if fmt == "audio" else to_silent(src) if fmt == "silent" else src
        jobs[job_id].update({"status": "done", "file": str(out), "engine": engine,
                             "completed_at": datetime.utcnow().isoformat()})
    except Exception as e:
        jobs[job_id].update({"status": "error", "error": humanize(str(e))})


# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/api/auth/status")
def auth_status():
    return {"logged_in": bool(_session["sessionid"] or COOKIES_FILE.exists()),
            "username": _session.get("username"), "ffmpeg": bool(FFMPEG)}

@app.post("/api/auth/login")
def login(b: LoginRequest):
    global _session
    if not b.username or not b.password:
        raise HTTPException(400, "Username and password are required.")
    try:
        c = web_login(b.username, b.password, b.two_factor_code or "")
    except RuntimeError as e:
        if "two_factor_required" in str(e):
            raise HTTPException(401, "Two-factor is on — enter your 6-digit code and try again.")
        raise HTTPException(401, humanize(str(e)))
    _session.update({"sessionid": c["sessionid"], "csrftoken": c["csrftoken"],
                     "ds_user_id": c.get("ds_user_id"), "username": b.username.lstrip("@")})
    SESSION_FILE.write_text(json.dumps(_session))
    log.info(f"Logged in @{_session['username']}")
    return {"ok": True, "username": _session["username"], "ffmpeg": bool(FFMPEG)}

@app.post("/api/auth/logout")
def logout():
    global _session
    _session = {"sessionid": None, "csrftoken": None, "ds_user_id": None, "username": None}
    SESSION_FILE.unlink(missing_ok=True)
    return {"ok": True}

@app.post("/api/auth/cookies")
def save_cookies(b: CookiesRequest):
    if "instagram" not in (b.cookies or "").lower():
        raise HTTPException(400, "That doesn't look like an Instagram cookies.txt.")
    COOKIES_FILE.write_text(b.cookies, encoding="utf-8")
    return {"ok": True}

@app.get("/health")
def health():
    return {"status": "ok", "yt_dlp": yt_dlp.version.__version__,
            "session": bool(_session["sessionid"]), "ffmpeg": bool(FFMPEG),
            "proxies": _PROXY_COUNT}

@app.post("/api/info")
def get_info(b: InfoRequest):
    try:
        kind, value = classify(b.input)
    except ValueError as e:
        raise HTTPException(400, str(e))
    try:
        info, engine = resolve(kind, value)
    except Exception as e:
        raise HTTPException(422, humanize(str(e)))
    return {"success": True, "engine": engine, "kind": kind,
            "uploader": info.get("uploader"), "description": (info.get("description") or "")[:300],
            "duration": info.get("duration"), "view_count": info.get("view_count"),
            "like_count": info.get("like_count"), "comment_count": info.get("comment_count"),
            "thumbnail": info.get("thumbnail"), "has_video": bool(info.get("video_url")),
            "ffmpeg": bool(FFMPEG)}

@app.post("/api/download")
def download_media(b: DownloadRequest, bg: BackgroundTasks):
    try:
        kind, value = classify(b.input)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if b.format in ("audio", "silent") and not FFMPEG:
        raise HTTPException(422, "ffmpeg missing. Run: pip install imageio-ffmpeg")
    job_id = uuid.uuid4().hex
    jobs[job_id] = {"id": job_id, "kind": kind, "value": value, "format": b.format,
                    "status": "queued", "created_at": datetime.utcnow().isoformat()}
    bg.add_task(run_job, job_id, kind, value, b.format)
    return {"job_id": job_id}

@app.get("/api/status/{job_id}")
def job_status(job_id: str):
    if job_id not in jobs: raise HTTPException(404, "Job not found")
    return jobs[job_id]

@app.get("/api/download/{job_id}/file")
def serve_file(job_id: str):
    job = jobs.get(job_id)
    if not job or job.get("status") != "done": raise HTTPException(404, "File not ready")
    path = Path(job["file"])
    if not path.exists(): raise HTTPException(404, "File missing")
    media = "audio/mpeg" if job["format"] == "audio" else "video/mp4"
    return FileResponse(path, media_type=media, filename=path.name)

@app.delete("/api/download/{job_id}/file")
def cleanup(job_id: str):
    job = jobs.pop(job_id, None)
    if job and job.get("file"): Path(job["file"]).unlink(missing_ok=True)
    return {"deleted": True}
